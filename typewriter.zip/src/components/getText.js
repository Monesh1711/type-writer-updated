export default () => {
  //   const texts = ["test1", "test2", "test3"];
  const texts = "looking at a prefilled text paragraph";
  //   return texts[Math.floor(Math.random() * texts.length)];
  return texts;
};
