export { getText } from "./typewriter/typewriter.action";
