export const GET_TEXT = "GET_TEXT";
